# Driver CWT-UWD series RS485 Small Weather Station

Sensor driver CWT-UWD series RS485 Small Weather Station ESP32-based devices running FreeRTOS. This small integrated weather station can be widely used in environmental detection, integrating wind speed, wind direction, temperature and humidity, noise collection, PM2.5 and PM10, atmospheric pressure, light, and accumulated rainfall.

