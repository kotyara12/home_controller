# Driver HDC1080 for ESP32 and ESP-IDF framework

Sensor driver HDC1080 for ESP32-based devices running FreeRTOS